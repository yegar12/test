import { Component } from '@angular/core';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpHeaders,HttpErrorResponse} from '@angular/common/http';
import {  Jsonp, Response, Headers, RequestOptions } from '@angular/http';

import { Observable, Subject, } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import {FormBuilder,FormGroup,FormControl,FormArray} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  
   title = "Form Example";
   myForm : FormGroup;
   columnname : string ;
   public list2 = [];
   selected: string = "hello";
  constructor(private fmb : FormBuilder,private http: HttpClient) { }
  ngOnInit() {
  this.myForm = this.fmb.group({
    email: '',
    phones: this.fmb.array([]),
 
  })

}

post() {
     
    const head = new HttpHeaders();
    head.append('Content-Type', 'application/json');
    headers.append("Access-Control-Allow-Origin", "*");
    let formData: FormData = new FormData(); 
    formData.append('name', "john"); 
    formData.append('age',"12");
    formData.append('mobile',"8398487394");
    this.http.post("http://localhost:8084/demo/api/users" ,formData,{headers:headers}) .subscribe((data) => console.log(data));
    //formData,{headers:headers}
     
  


    //this.http.get("http://jsonplaceholder.typicode.com/users").subscribe((data) => console.log(data))
    //formData,{headers:headers}
     console.log("clicked" + this.http); 
  
}
get phoneForms() {
  return this.myForm.get('phones') as FormArray
}

addPhone() {

  const phone = this.fmb.group({ 
    [this.selected]: [],
   
  })

  this.phoneForms.push(phone);
}

deletePhone(i) {
  this.phoneForms.removeAt(i)
}
   
}
