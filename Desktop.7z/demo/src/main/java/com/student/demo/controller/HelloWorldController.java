package com.student.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HelloWorldController {

	@RequestMapping("/hello")
	public String hello(ModelMap modelmap){
                //smodelmap.put("hello", "hello");
		return "test.html";
	}
}