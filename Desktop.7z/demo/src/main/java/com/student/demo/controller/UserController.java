package com.student.demo.controller;


import com.student.demo.exception.ResourceNotFoundException;
import com.student.demo.model.User;
import com.student.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    UserRepository noteRepository;

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return noteRepository.findAll();
    }

    @PostMapping("/users")
    public User createUser(@Valid @RequestBody User note) {
        return noteRepository.save(note);
    }

    @GetMapping("/users/{id}")
    public User getUserById(@PathVariable(value = "id") Long noteId) {
        return noteRepository.findById(noteId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", noteId));
    }

    @PutMapping("/users/{id}")
    public User updateUser(@PathVariable(value = "id") Long noteId,
                                           @Valid @RequestBody User noteDetails) {

        User note = noteRepository.findById(noteId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", noteId));

        note.setName(noteDetails.getName());
        note.setAge(noteDetails.getAge());

        User updatedUser = noteRepository.save(note);
        return updatedUser;
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable(value = "id") Long noteId) {
        User note = noteRepository.findById(noteId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", noteId));

        noteRepository.delete(note);

        return ResponseEntity.ok().build();
    }
}
