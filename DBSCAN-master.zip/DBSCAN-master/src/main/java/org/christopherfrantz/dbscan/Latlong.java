/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.christopherfrantz.dbscan;

/**
 *
 * @author Man
 */
public class Latlong{
    
    public Double lat;
public Double lon;
    public Latlong(Double lat, Double lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    @Override
    public String toString() {
        return "Latlong{" + "lat=" + lat + ", lon=" + lon + '}';
    }

 
    
    
    
}
